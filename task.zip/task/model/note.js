var mongoose = require('mongoose');

// connect mongoDb
mongoose.connect('mongodb://localhost/test', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})

var Schema = mongoose.Schema;

var blogSchema = new Schema({
    title: String,
    author: String,
    briefly: String,
    imgSrc: String,
    body: String,
    date: {
        type: Date,
        default: Date.now
    }
})

var Blog = mongoose.model('Blog', blogSchema);


module.exports = Blog