$().ready(function () {
    $('#send').click(function () {
        let title = $('#title').val();
        let briefly = $('#briefly').val();
        var imgFile = $('#fupPhoto')[0].files[0];
        let info = $('#info').val()
        // let info = editor.txt.html();
        if(title == ''){
            alert('title is null')
        }else if(briefly == ''){
            alert('briefly is null')
        }else if(imgFile == undefined){
            alert('Please submit pictures')
        }else if(info == ''){
            alert('detail is null')
        }
        let data = new FormData();
        data.append('title', title);
        data.append('imgFile', imgFile);
        data.append('info', info);
        data.append('briefly', briefly);
        
        $.ajax({
            url: 'add',
            type: 'post',
            data,
            processData: false,
            contentType: false,
            success: function (res) {
                if(res.status == 200){
                    alert('successfully added')
                    window.location.href='tutors'
                }
            },
            error: function (e) {
                console.log(e.responseJSON.message);
            }
        })
    })
    $('#fupPhoto').change(function () {
        var imgFile = $('#fupPhoto')[0].files[0];
        var objFile = getObjectURL(imgFile);
        $('#showImg').attr('src', objFile).show();
    })
    function getObjectURL(file) {

        var url = null;

        if (window.createObjectURL != undefined) { // basic

            url = window.createObjectURL(file);

        } else if (window.URL != undefined) { // mozilla(firefox)

            url = window.URL.createObjectURL(file);

        } else if (window.webkitURL != undefined) { // webkit or chrome

            url = window.webkitURL.createObjectURL(file);

        }

        return url;

    }
})